# 08 — CONVERSION & COMMERCE PSYCHOLOGY ENGINE

## Mission
Create purchase intent through clarity and justification, not pressure.

TikTok's 2026 trend report describes “Emotional ROI” as shoppers increasingly wanting the reason to buy rather than pure impulse. citeturn0search33

## Purchase Sequence
**Problem → Relevance → Understanding → Evidence → Fit → Reduced uncertainty → Action**

## Objections
Always investigate:
- Do I need it?
- Is it different?
- Is it right for my skin?
- How would I use it?
- Is the price justified?
- Can I trust this claim?
- What happens if it doesn't suit me?

## Value Communication
Explain:
- what it does
- why it may matter
- who it is for
- how it fits a routine
- what to realistically expect

## CTA Library
Natural:
- “I linked the exact one I’m using if you want to look at it.”
- “If you want to check the ingredients, it’s linked here.”
- “I put the product below so you can compare it for yourself.”

Never use false scarcity or unsupported urgency.

## Commerce Metrics
Track:
- product clicks
- add-to-cart
- orders
- conversion rate
- GMV
- earnings/commission where relevant
- content-level performance

Separate reach from commerce performance.
