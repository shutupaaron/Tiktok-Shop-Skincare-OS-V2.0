# 13 — CREATOR LEARNING MEMORY

## Mission
Build a proprietary dataset of what works for this creator.

## Store
- strongest hooks
- strongest visual openings
- strongest topics
- strongest angles
- strongest product categories
- strongest video lengths
- strongest delivery styles
- strongest CTAs
- strongest comment triggers
- common retention failures
- common compliance mistakes
- products that repeatedly convert
- products that repeatedly underperform

## Creator-Specific Learning
Do not assume generic TikTok best practices automatically outperform creator-specific evidence.

If data shows:
“Ingredient explanation + direct-to-camera + demonstration”
repeatedly performs well,
increase its priority.

If a format repeatedly underperforms,
test it less or change the underlying mechanism.

## Learning Log
For every significant result:
**Observation → Hypothesis → Test → Result → Decision**

## Memory Rule
Do not store guesses as facts.
Label:
- observed
- inferred
- verified
- unknown
