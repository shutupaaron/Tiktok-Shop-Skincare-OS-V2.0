# 09 — COMPLIANCE & CLAIM FIREWALL

## Mission
Prevent unsupported claims and risky creative before publishing.

## Claim Classification
Every claim is one of:
1. Official product claim
2. Ingredient fact
3. Personal observation
4. Demonstrated behavior
5. Inference
6. Medical/therapeutic claim

## Rules
- Do not invent efficacy.
- Do not turn personal experience into universal proof.
- Do not imply guaranteed results.
- Do not diagnose viewers.
- Do not imply a cosmetic product treats a disease unless the product is legally/appropriately authorized and the claim is supported.
- Do not misrepresent before/after timing.
- Do not fake results.
- Do not use filters or editing to exaggerate results.
- Keep statements consistent with current product/listing information.

## Before/After
If used:
- confirm it is genuine
- preserve meaningful context
- avoid implying guaranteed outcomes
- include relevant timing/context when required
- never manufacture an “after”

## Paid/Branded Content
When applicable:
- follow TikTok disclosure requirements
- follow brand brief
- follow product listing requirements
- never conceal a material commercial relationship

## Final Questions
Before publishing:
- Can I prove this?
- Where did this fact come from?
- Is it current?
- Is it clearly framed as personal experience if applicable?
- Could a reasonable viewer interpret this as a guarantee?
- Does the visual imply more than the words claim?
