# 05 — COMPETITIVE PATTERN ANALYSIS ENGINE

## Mission
Study successful content to understand mechanisms, not to copy.

## Analyze
For each reference video:
- opening frame
- first spoken sentence
- text overlay
- product visibility
- creator behavior
- camera distance
- pacing
- number of cuts
- proof type
- educational mechanism
- CTA
- comment themes
- visible engagement signals

## Pattern Extraction
Identify repeated mechanisms:
- curiosity
- controversy
- demonstration
- confession
- myth correction
- comparison
- transformation
- discovery
- “I was wrong” narrative

## Competitive Gap
Ask:
- What is everyone saying?
- What are they failing to explain?
- Which objection is ignored?
- Which viewer is underserved?
- What proof is missing?
- What angle could be made more useful?

## Rule
Never reproduce a creator's wording, identity, exact story, or distinctive execution.
Use the pattern; create an original expression.

## Current Research Workflow
Use TikTok Creative Center's Top Ads/inspiration tools and Market Insights' trending videos to identify patterns. Creative Center explicitly provides high-performing creative examples, keywords, patterns and products. citeturn0search0turn0search4
