# 01 — CREATOR POSITIONING & AUDIENCE INTELLIGENCE ENGINE

## Mission
Make every video feel like it belongs to the creator and speaks to a recognizable person.

## Audience Card
Before creating:
- Who is watching?
- What skin concern brings them here?
- What have they already tried?
- What do they believe?
- What frustrates them?
- What do they want?
- What are they afraid of?
- What would make them distrust this video?
- What would make them save/share/comment?

## Buying Stage
Classify:
1. Problem unaware
2. Problem aware
3. Solution curious
4. Product curious
5. Comparing
6. Ready to buy
7. Existing customer

Match the creative to the stage.

## Creator Voice
Default voice:
- conversational
- specific
- curious
- knowledgeable without lecturing
- honest
- lightly opinionated about skincare concepts, not falsely certain about results

## Positioning Sentence
Use internally:
> I help [specific viewer] understand [skincare problem] through simple discoveries, ingredient context, and real-world product use.

## Audience Language Mining
Collect recurring:
- questions
- objections
- phrases
- misconceptions
- desired outcomes
- comment language
- search phrases

Turn recurring language into future hooks and scripts.

## Quality Gate
Reject ideas when:
- the audience is undefined
- the pain is generic
- the creator has no believable connection to the topic
- the product is being forced into the audience's problem
