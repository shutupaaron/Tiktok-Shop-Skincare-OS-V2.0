# 03 — PRODUCT & SKINCARE INTELLIGENCE ENGINE

## Mission
Understand the product before creating content.

## Product Dossier
Capture:
- exact product name
- category
- size
- texture
- intended use
- directions
- ingredient list
- highlighted ingredients
- brand claims
- supported benefits
- known limitations
- target user
- contraindications/warnings when supplied
- price/offer only when current
- listing availability only when verified

## Evidence Hierarchy
1. Official product/listing information
2. Brand-provided creator brief
3. Ingredient/formulation documentation
4. Reputable educational sources
5. Personal experience — clearly labeled as personal experience
6. Inference — clearly labeled as inference

Never convert an inference into a product claim.

## Ingredient Translation
For every important ingredient:
- what it is
- what it generally does
- why it appears in this formulation
- what it does NOT prove
- how to explain it simply

## Formulation Logic
Ask:
- What problem is the formula designed around?
- What role does each hero ingredient play?
- How does texture influence use?
- What routine step does it occupy?
- What user behavior increases usability?

## Product-Fit Test
A product earns a video when it has:
- a recognizable problem
- an interesting story
- demonstrability
- differentiation
- evidence
- audience fit

If not, do not force it.
