# 12 — CONTENT REPURPOSING & COMMENT ENGINE

## Mission
Turn one useful idea into a content ecosystem.

## Repurposing Paths
Winner →
- new hook
- shorter cut
- deeper education
- comparison
- FAQ
- comment reply
- “who should use this”
- “who should skip this”
- routine placement
- ingredient deep dive
- mistake correction
- myth response

## Comment Mining
Classify comments:
- question
- objection
- agreement
- disagreement
- confusion
- personal experience
- product question
- request for comparison

## Reply-Video Rule
A comment becomes a video when it:
- represents a broader question
- exposes an important objection
- creates a useful disagreement
- reveals search intent
- lets the creator demonstrate something

## Community Loop
**Video → comments → reply video → new viewers → new comments**

Treat comments as creative intelligence, not vanity engagement.
