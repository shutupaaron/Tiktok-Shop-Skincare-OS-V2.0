# 10 — CREATIVE TESTING ENGINE

## Mission
Turn content creation into controlled learning.

## Test One Major Variable at a Time
Possible variables:
- hook
- opening visual
- angle
- belief shift
- proof type
- product reveal timing
- CTA
- video length
- pacing
- creator delivery

## Test Matrix
Build:
A — problem hook
B — discovery hook
C — mistake hook
D — ingredient hook
E — comparison hook

Keep the core product fact and audience stable where possible.

## Evaluation
Look at:
- early retention
- average watch time
- completion/rewatch signals
- comments
- shares/saves
- profile visits
- product clicks
- orders/conversion

## Testing Rule
Do not declare a concept “bad” from one weak execution.
Ask whether:
- the hook failed
- the audience was wrong
- the proof was weak
- the product fit was weak
- the execution was weak
- the offer/listing was weak

## Winner Expansion
When something works:
- new hook
- new opening visual
- comment reply
- shorter version
- longer educational version
- comparison
- follow-up objection
- routine integration
