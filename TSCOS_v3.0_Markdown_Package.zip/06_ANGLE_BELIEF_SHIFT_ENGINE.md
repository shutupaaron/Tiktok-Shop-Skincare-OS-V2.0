# 06 — ANGLE & BELIEF-SHIFT ENGINE

## Mission
Turn a product into a meaningful story.

## Angle Families
1. Problem/solution
2. Mistake correction
3. Ingredient education
4. Myth busting
5. Personal discovery
6. Routine integration
7. Comparison
8. “What I wish I knew”
9. Who should choose this
10. Who should skip this
11. Texture/use demonstration
12. Comment-response

## Belief Shift Map
**Current belief → tension → evidence → new understanding → action**

Example:
“I need stronger skincare”
→ repeated irritation
→ barrier-support education
→ “stronger isn't always the answer”
→ consider a gentler routine

## Trust Rule
A belief shift must be earned.
Do not manufacture fear, shame, false urgency, or certainty.

## Product Role
The product can be:
- the example
- the demonstration
- the tool
- the discovery
- the comparison point
- the routine step

It does not always need to be the “hero.”

## Output
Generate multiple angles and identify:
- strongest audience fit
- strongest proof potential
- strongest story
- strongest product relevance
