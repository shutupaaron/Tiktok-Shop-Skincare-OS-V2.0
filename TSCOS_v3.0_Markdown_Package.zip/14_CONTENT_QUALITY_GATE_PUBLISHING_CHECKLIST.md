# 14 — CONTENT QUALITY GATE & PUBLISHING CHECKLIST

## Gate 1 — Audience
- [ ] Specific viewer identified
- [ ] Recognizable problem
- [ ] Desired outcome understood

## Gate 2 — Creative
- [ ] Visual opening
- [ ] Verbal hook
- [ ] Text hook
- [ ] Curiosity/tension
- [ ] Useful payoff
- [ ] Strong pacing

## Gate 3 — Education
- [ ] Viewer learns something
- [ ] Explanation is simple
- [ ] No unnecessary jargon
- [ ] Product is not the only information

## Gate 4 — Evidence
- [ ] Claims have a source
- [ ] Demonstrations are genuine
- [ ] Personal experience is framed as personal
- [ ] No fabricated results

## Gate 5 — Product
- [ ] Product naturally fits the story
- [ ] Correct product
- [ ] Current listing/brief checked
- [ ] Audience fit makes sense

## Gate 6 — Commerce
- [ ] CTA is natural
- [ ] Product path is clear
- [ ] No false urgency
- [ ] Value is understandable

## Gate 7 — Compliance
- [ ] Disclosure handled when required
- [ ] Claims reviewed
- [ ] Before/after reviewed
- [ ] No medical overreach
- [ ] Visuals do not imply unsupported outcomes

## Gate 8 — Learning
- [ ] Test hypothesis documented
- [ ] Primary metric selected
- [ ] Follow-up concept identified

## Final Rule
If the video feels like an advertisement before it feels like useful content, rewrite it.
