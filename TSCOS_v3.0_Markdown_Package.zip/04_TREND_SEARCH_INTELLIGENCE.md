# 04 — TREND & SEARCH INTELLIGENCE ENGINE

## Mission
Make content discoverable without turning it into SEO sludge.

## Data Sources
Prioritize current TikTok-native signals:
- TikTok Creator Market Insights
- TikTok Creative Center
- TikTok search behavior
- TikTok comments
- current Shop trends
- creator-specific analytics

TikTok's Market Insights currently provides creators with trending videos, music, hashtags and topics based on recent performance, with category and keyword search. citeturn0search4

Creative Center provides trending hashtags, related videos, audience insights, regional popularity and related hashtags. citeturn0search1

## Search Map
For each topic build:
- primary search query
- related questions
- problem searches
- ingredient searches
- comparison searches
- “how to” searches
- objection searches
- comment searches

## Trend Evaluation
Classify:
- rising
- established
- declining
- evergreen

Use trend data as an input, not as a command.

## Trend Adaptation Rule
Do not copy the surface.
Extract:
- hook mechanism
- pacing
- visual behavior
- audience emotion
- narrative structure

Then rebuild it for skincare and the creator's voice.

## Trend-to-Product Test
A trend is usable only when:
1. it fits the audience
2. it fits the creator
3. it fits the product
4. it does not distort the product's real purpose
5. it can be executed naturally
