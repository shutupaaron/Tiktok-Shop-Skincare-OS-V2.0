# TSCOS v3.0 — COMPLETE MARKDOWN PACKAGE



---

# FILE: 00_MASTER_TSCOS_v3.0.md

# TSCOS v3.0 — MASTER TIKTOK SKINCARE CREATOR OPERATING SYSTEM
**Version:** 3.0  
**Date:** September 22, 2026  
**Purpose:** A production operating system for organic-feeling TikTok skincare and TikTok Shop content.

## 1. Mission
Build a trusted skincare creator brand that earns attention, teaches something useful, creates a belief shift, demonstrates why a product is relevant, and gives viewers a natural next step.

Core sequence:

**Qualified Attention → Curiosity → Value → Evidence → Trust → Product Relevance → Action → Learning**

The system optimizes for **qualified attention**, not views alone.

## 2. Creator Positioning
The creator is a knowledgeable friend who discovers, tests, explains, and contextualizes skincare.

Avoid:
- corporate language
- forced hype
- generic praise
- fake urgency
- unsupported claims
- pretending every product is life-changing

Use:
- discovery
- specificity
- honest observations
- simple education
- visible evidence
- real routine context
- appropriate uncertainty

## 3. The TSCOS Flywheel
1. **Discover** — audience, search, trends, comments, products
2. **Understand** — pain, desire, objection, belief, evidence
3. **Design** — angle, hook, story, proof, visual mechanism
4. **Create** — script, shot list, edit plan, CTA
5. **Verify** — claims, disclosure, product/listing accuracy, policy
6. **Publish** — native TikTok execution
7. **Diagnose** — retention, engagement, clicks, conversion, comments
8. **Learn** — store what worked
9. **Iterate** — new hooks, angles, formats, follow-ups

## 4. Module Map
01 — Creator Positioning & Audience Intelligence  
02 — Script Intelligence & Creative Engineering  
03 — Product & Skincare Intelligence  
04 — Trend & Search Intelligence  
05 — Competitive Pattern Analysis  
06 — Angle & Belief-Shift Engine  
07 — Visual Creative Direction  
08 — Conversion & Commerce Psychology  
09 — Compliance & Claim Firewall  
10 — Creative Testing Engine  
11 — Performance Diagnosis & Analytics  
12 — Content Repurposing & Comment Engine  
13 — Creator Learning Memory  
14 — Content Quality Gate & Publishing Checklist

## 5. Non-Negotiables
- Never invent product facts.
- Separate brand claims, ingredient facts, personal experience, inference, and medical claims.
- Product integration must make narrative sense.
- Every video needs a reason to continue watching.
- Every important claim should have an evidence source.
- Show when possible; do not merely tell.
- Use current trend data when trend relevance matters.
- Do not copy viral videos; extract mechanisms and create an original expression.
- A weak product/video premise should be rejected before scripting.
- After publishing, the result becomes input for the next creative.

## 6. Current TikTok Intelligence Layer
TikTok's 2026 trend report highlights **Reali-TEA, Curiosity Detours, and Emotional ROI**: audiences are responding to more real, discovery-oriented experiences and shoppers increasingly want a reason to buy rather than pure impulse. TikTok's current creator Market Insights also provides trending videos, music, hashtags and topics from the last 30 days, including views and conversion-oriented signals. citeturn0search33turn0search4

TikTok Creative Center provides current trend, keyword, product and high-performing creative inspiration, while Shop Creative Hub provides creative-level performance reporting for eligible Shop content. citeturn0search0turn0search9

## 7. Definition of a Win
A successful video can:
- stop the right viewer
- hold attention
- teach something
- create trust
- trigger a useful conversation
- drive qualified product interest
- generate clicks/orders
- produce a reusable learning

**Never judge the entire system from views alone.**


---

# FILE: 01_CREATOR_POSITIONING_AUDIENCE_INTELLIGENCE.md

# 01 — CREATOR POSITIONING & AUDIENCE INTELLIGENCE ENGINE

## Mission
Make every video feel like it belongs to the creator and speaks to a recognizable person.

## Audience Card
Before creating:
- Who is watching?
- What skin concern brings them here?
- What have they already tried?
- What do they believe?
- What frustrates them?
- What do they want?
- What are they afraid of?
- What would make them distrust this video?
- What would make them save/share/comment?

## Buying Stage
Classify:
1. Problem unaware
2. Problem aware
3. Solution curious
4. Product curious
5. Comparing
6. Ready to buy
7. Existing customer

Match the creative to the stage.

## Creator Voice
Default voice:
- conversational
- specific
- curious
- knowledgeable without lecturing
- honest
- lightly opinionated about skincare concepts, not falsely certain about results

## Positioning Sentence
Use internally:
> I help [specific viewer] understand [skincare problem] through simple discoveries, ingredient context, and real-world product use.

## Audience Language Mining
Collect recurring:
- questions
- objections
- phrases
- misconceptions
- desired outcomes
- comment language
- search phrases

Turn recurring language into future hooks and scripts.

## Quality Gate
Reject ideas when:
- the audience is undefined
- the pain is generic
- the creator has no believable connection to the topic
- the product is being forced into the audience's problem


---

# FILE: 02_SCRIPT_INTELLIGENCE_CREATIVE_ENGINEERING.md

# 02 — SCRIPT INTELLIGENCE & CREATIVE ENGINEERING ENGINE v3.0

## Role
Act as an elite TikTok creator, skincare educator, creative director, consumer psychologist, direct-response strategist, and TikTok Shop content strategist.

## Primary Objective
Engineer:
**Attention → Curiosity → Education → Evidence → Trust → Product Relevance → Action**

Do not write ads. Build useful native TikTok experiences.

## Phase 1 — Intelligence
Identify:
- audience
- problem
- desire
- hidden fear
- objection
- search intent
- relevant trend
- product differentiator
- evidence available
- belief that must change

## Phase 2 — Angle Generation
Generate 5–8:
- education
- mistake correction
- personal discovery
- ingredient explanation
- myth correction
- comparison
- routine integration
- trend adaptation
- storytime/discovery

Score internally for:
- qualified attention
- curiosity
- educational value
- proof potential
- product fit
- conversion relevance
- authenticity

Do not publish a numerical score as a ranking for the audience; use scores only as internal creative triage.

## Phase 3 — Belief Shift
Define:
**Before:** what the viewer currently thinks.  
**After:** what they should understand after watching.

The video should earn the belief shift through information or experience, not manipulation.

## Phase 4 — Hook Engineering
Build each opening as:
**Visual Hook + Verbal Hook + Text Hook**

Hook mechanisms:
- pain recognition
- curiosity gap
- unexpected insight
- misconception
- personal discovery
- demonstration
- contrast
- question
- consequence

Avoid:
- “Hey guys”
- generic introductions
- empty superlatives
- “you NEED this”
- fake urgency

## Phase 5 — Retention Architecture
Use:
**Hook → Tension → Value → Proof → Product Relevance → Resolution → CTA**

Do not force a fixed duration. Let the idea determine length.

## Phase 6 — Product Integration
The product should answer a question created by the story.

Bad:
> “Here is the product.”

Better:
> “Here is what I learned about the problem, and this is where this product makes sense.”

## Phase 7 — Proof
Prefer visible evidence:
- texture
- application
- routine placement
- ingredient label
- product demonstration
- comparison
- personal usage
- clearly attributed brand information

Never fabricate proof.

## Output
### Strategic Analysis
Audience, problem, desire, objection, belief shift, angle, evidence.

### Creative Direction
Concept, opening visual, creator behavior, B-roll, text overlays, editing rhythm.

### Hook Set
10 distinct hooks; identify the strongest candidates and why.

### Script
For every beat:
- dialogue
- visual
- text overlay
- transition/pattern interrupt

### CTA
Use a natural next step:
- check ingredients
- see the linked product
- learn more
- ask a genuine question

### Caption
Create one concise caption aligned to search intent and viewer value.

### Comment Strategy
Predict likely questions and turn strong questions into follow-up videos.

## Final QC
Check:
- hook clarity
- retention tension
- authenticity
- education
- proof
- product fit
- claim accuracy
- Shop suitability
- CTA naturalness


---

# FILE: 03_PRODUCT_SKINCARE_INTELLIGENCE.md

# 03 — PRODUCT & SKINCARE INTELLIGENCE ENGINE

## Mission
Understand the product before creating content.

## Product Dossier
Capture:
- exact product name
- category
- size
- texture
- intended use
- directions
- ingredient list
- highlighted ingredients
- brand claims
- supported benefits
- known limitations
- target user
- contraindications/warnings when supplied
- price/offer only when current
- listing availability only when verified

## Evidence Hierarchy
1. Official product/listing information
2. Brand-provided creator brief
3. Ingredient/formulation documentation
4. Reputable educational sources
5. Personal experience — clearly labeled as personal experience
6. Inference — clearly labeled as inference

Never convert an inference into a product claim.

## Ingredient Translation
For every important ingredient:
- what it is
- what it generally does
- why it appears in this formulation
- what it does NOT prove
- how to explain it simply

## Formulation Logic
Ask:
- What problem is the formula designed around?
- What role does each hero ingredient play?
- How does texture influence use?
- What routine step does it occupy?
- What user behavior increases usability?

## Product-Fit Test
A product earns a video when it has:
- a recognizable problem
- an interesting story
- demonstrability
- differentiation
- evidence
- audience fit

If not, do not force it.


---

# FILE: 04_TREND_SEARCH_INTELLIGENCE.md

# 04 — TREND & SEARCH INTELLIGENCE ENGINE

## Mission
Make content discoverable without turning it into SEO sludge.

## Data Sources
Prioritize current TikTok-native signals:
- TikTok Creator Market Insights
- TikTok Creative Center
- TikTok search behavior
- TikTok comments
- current Shop trends
- creator-specific analytics

TikTok's Market Insights currently provides creators with trending videos, music, hashtags and topics based on recent performance, with category and keyword search. citeturn0search4

Creative Center provides trending hashtags, related videos, audience insights, regional popularity and related hashtags. citeturn0search1

## Search Map
For each topic build:
- primary search query
- related questions
- problem searches
- ingredient searches
- comparison searches
- “how to” searches
- objection searches
- comment searches

## Trend Evaluation
Classify:
- rising
- established
- declining
- evergreen

Use trend data as an input, not as a command.

## Trend Adaptation Rule
Do not copy the surface.
Extract:
- hook mechanism
- pacing
- visual behavior
- audience emotion
- narrative structure

Then rebuild it for skincare and the creator's voice.

## Trend-to-Product Test
A trend is usable only when:
1. it fits the audience
2. it fits the creator
3. it fits the product
4. it does not distort the product's real purpose
5. it can be executed naturally


---

# FILE: 05_COMPETITIVE_PATTERN_ANALYSIS.md

# 05 — COMPETITIVE PATTERN ANALYSIS ENGINE

## Mission
Study successful content to understand mechanisms, not to copy.

## Analyze
For each reference video:
- opening frame
- first spoken sentence
- text overlay
- product visibility
- creator behavior
- camera distance
- pacing
- number of cuts
- proof type
- educational mechanism
- CTA
- comment themes
- visible engagement signals

## Pattern Extraction
Identify repeated mechanisms:
- curiosity
- controversy
- demonstration
- confession
- myth correction
- comparison
- transformation
- discovery
- “I was wrong” narrative

## Competitive Gap
Ask:
- What is everyone saying?
- What are they failing to explain?
- Which objection is ignored?
- Which viewer is underserved?
- What proof is missing?
- What angle could be made more useful?

## Rule
Never reproduce a creator's wording, identity, exact story, or distinctive execution.
Use the pattern; create an original expression.

## Current Research Workflow
Use TikTok Creative Center's Top Ads/inspiration tools and Market Insights' trending videos to identify patterns. Creative Center explicitly provides high-performing creative examples, keywords, patterns and products. citeturn0search0turn0search4


---

# FILE: 06_ANGLE_BELIEF_SHIFT_ENGINE.md

# 06 — ANGLE & BELIEF-SHIFT ENGINE

## Mission
Turn a product into a meaningful story.

## Angle Families
1. Problem/solution
2. Mistake correction
3. Ingredient education
4. Myth busting
5. Personal discovery
6. Routine integration
7. Comparison
8. “What I wish I knew”
9. Who should choose this
10. Who should skip this
11. Texture/use demonstration
12. Comment-response

## Belief Shift Map
**Current belief → tension → evidence → new understanding → action**

Example:
“I need stronger skincare”
→ repeated irritation
→ barrier-support education
→ “stronger isn't always the answer”
→ consider a gentler routine

## Trust Rule
A belief shift must be earned.
Do not manufacture fear, shame, false urgency, or certainty.

## Product Role
The product can be:
- the example
- the demonstration
- the tool
- the discovery
- the comparison point
- the routine step

It does not always need to be the “hero.”

## Output
Generate multiple angles and identify:
- strongest audience fit
- strongest proof potential
- strongest story
- strongest product relevance


---

# FILE: 07_VISUAL_CREATIVE_DIRECTION.md

# 07 — VISUAL CREATIVE DIRECTION ENGINE

## Mission
Design what the viewer sees, not just what they hear.

## Opening Requirement
Every video begins with a visual event.

Examples:
- immediate application
- product in hand
- texture close-up
- face-to-camera statement
- comparison
- unexpected object/action
- label/ingredient reveal

## Visual Hook Stack
**Frame + Movement + Text + Speech**

At least two should be active immediately; three is preferred when natural.

## Shot Library
- direct-to-camera
- macro texture
- hand application
- product close-up
- shelf/routine context
- ingredient label
- side-by-side
- product-in-use
- reaction
- comment screenshot
- package reveal

## Editing
Use:
- purposeful cuts
- visual resets
- occasional punch-ins
- text changes when the idea changes
- pattern interrupts at natural information boundaries

Avoid:
- constant zooming
- frantic cuts without informational purpose
- excessive text
- hiding the creator behind product footage

## Real-Life Usage
Show where the product actually fits in the routine.

## Accessibility
Keep critical information:
- spoken clearly
- visible in readable text
- synchronized with the idea


---

# FILE: 08_CONVERSION_COMMERCE_PSYCHOLOGY.md

# 08 — CONVERSION & COMMERCE PSYCHOLOGY ENGINE

## Mission
Create purchase intent through clarity and justification, not pressure.

TikTok's 2026 trend report describes “Emotional ROI” as shoppers increasingly wanting the reason to buy rather than pure impulse. citeturn0search33

## Purchase Sequence
**Problem → Relevance → Understanding → Evidence → Fit → Reduced uncertainty → Action**

## Objections
Always investigate:
- Do I need it?
- Is it different?
- Is it right for my skin?
- How would I use it?
- Is the price justified?
- Can I trust this claim?
- What happens if it doesn't suit me?

## Value Communication
Explain:
- what it does
- why it may matter
- who it is for
- how it fits a routine
- what to realistically expect

## CTA Library
Natural:
- “I linked the exact one I’m using if you want to look at it.”
- “If you want to check the ingredients, it’s linked here.”
- “I put the product below so you can compare it for yourself.”

Never use false scarcity or unsupported urgency.

## Commerce Metrics
Track:
- product clicks
- add-to-cart
- orders
- conversion rate
- GMV
- earnings/commission where relevant
- content-level performance

Separate reach from commerce performance.


---

# FILE: 09_COMPLIANCE_CLAIM_FIREWALL.md

# 09 — COMPLIANCE & CLAIM FIREWALL

## Mission
Prevent unsupported claims and risky creative before publishing.

## Claim Classification
Every claim is one of:
1. Official product claim
2. Ingredient fact
3. Personal observation
4. Demonstrated behavior
5. Inference
6. Medical/therapeutic claim

## Rules
- Do not invent efficacy.
- Do not turn personal experience into universal proof.
- Do not imply guaranteed results.
- Do not diagnose viewers.
- Do not imply a cosmetic product treats a disease unless the product is legally/appropriately authorized and the claim is supported.
- Do not misrepresent before/after timing.
- Do not fake results.
- Do not use filters or editing to exaggerate results.
- Keep statements consistent with current product/listing information.

## Before/After
If used:
- confirm it is genuine
- preserve meaningful context
- avoid implying guaranteed outcomes
- include relevant timing/context when required
- never manufacture an “after”

## Paid/Branded Content
When applicable:
- follow TikTok disclosure requirements
- follow brand brief
- follow product listing requirements
- never conceal a material commercial relationship

## Final Questions
Before publishing:
- Can I prove this?
- Where did this fact come from?
- Is it current?
- Is it clearly framed as personal experience if applicable?
- Could a reasonable viewer interpret this as a guarantee?
- Does the visual imply more than the words claim?


---

# FILE: 10_CREATIVE_TESTING_ENGINE.md

# 10 — CREATIVE TESTING ENGINE

## Mission
Turn content creation into controlled learning.

## Test One Major Variable at a Time
Possible variables:
- hook
- opening visual
- angle
- belief shift
- proof type
- product reveal timing
- CTA
- video length
- pacing
- creator delivery

## Test Matrix
Build:
A — problem hook
B — discovery hook
C — mistake hook
D — ingredient hook
E — comparison hook

Keep the core product fact and audience stable where possible.

## Evaluation
Look at:
- early retention
- average watch time
- completion/rewatch signals
- comments
- shares/saves
- profile visits
- product clicks
- orders/conversion

## Testing Rule
Do not declare a concept “bad” from one weak execution.
Ask whether:
- the hook failed
- the audience was wrong
- the proof was weak
- the product fit was weak
- the execution was weak
- the offer/listing was weak

## Winner Expansion
When something works:
- new hook
- new opening visual
- comment reply
- shorter version
- longer educational version
- comparison
- follow-up objection
- routine integration


---

# FILE: 11_PERFORMANCE_DIAGNOSIS_ANALYTICS.md

# 11 — PERFORMANCE DIAGNOSIS & ANALYTICS ENGINE

## Mission
Convert every post into a lesson.

## Diagnostic Funnel
**Impression → 1–3s hold → sustained watch → completion/rewatch → engagement → profile/product interaction → click → order**

## Diagnose by Symptom

### Weak opening
Likely issue:
- unclear promise
- weak visual event
- generic first line
- slow setup

### Strong opening, weak middle
Likely issue:
- promise not fulfilled
- too much filler
- weak information density
- product interruption

### Strong watch, weak clicks
Possible issue:
- product relevance unclear
- CTA weak
- viewer learned but did not understand why the product matters

### Strong clicks, weak orders
Possible issue:
- offer/listing
- price/value perception
- product fit
- shopper uncertainty

Do not automatically blame the script.

## Data Capture
For every meaningful post record:
- date
- product
- concept
- angle
- hook
- length
- views
- watch/retention metrics available
- engagement
- shares/saves
- profile visits
- product clicks
- orders
- GMV/earnings where available
- top comments
- lesson

## Learning Rule
A post is not finished when it is published.
It is finished when its result has been interpreted and stored.


---

# FILE: 12_CONTENT_REPURPOSING_COMMENT_ENGINE.md

# 12 — CONTENT REPURPOSING & COMMENT ENGINE

## Mission
Turn one useful idea into a content ecosystem.

## Repurposing Paths
Winner →
- new hook
- shorter cut
- deeper education
- comparison
- FAQ
- comment reply
- “who should use this”
- “who should skip this”
- routine placement
- ingredient deep dive
- mistake correction
- myth response

## Comment Mining
Classify comments:
- question
- objection
- agreement
- disagreement
- confusion
- personal experience
- product question
- request for comparison

## Reply-Video Rule
A comment becomes a video when it:
- represents a broader question
- exposes an important objection
- creates a useful disagreement
- reveals search intent
- lets the creator demonstrate something

## Community Loop
**Video → comments → reply video → new viewers → new comments**

Treat comments as creative intelligence, not vanity engagement.


---

# FILE: 13_CREATOR_LEARNING_MEMORY.md

# 13 — CREATOR LEARNING MEMORY

## Mission
Build a proprietary dataset of what works for this creator.

## Store
- strongest hooks
- strongest visual openings
- strongest topics
- strongest angles
- strongest product categories
- strongest video lengths
- strongest delivery styles
- strongest CTAs
- strongest comment triggers
- common retention failures
- common compliance mistakes
- products that repeatedly convert
- products that repeatedly underperform

## Creator-Specific Learning
Do not assume generic TikTok best practices automatically outperform creator-specific evidence.

If data shows:
“Ingredient explanation + direct-to-camera + demonstration”
repeatedly performs well,
increase its priority.

If a format repeatedly underperforms,
test it less or change the underlying mechanism.

## Learning Log
For every significant result:
**Observation → Hypothesis → Test → Result → Decision**

## Memory Rule
Do not store guesses as facts.
Label:
- observed
- inferred
- verified
- unknown


---

# FILE: 14_CONTENT_QUALITY_GATE_PUBLISHING_CHECKLIST.md

# 14 — CONTENT QUALITY GATE & PUBLISHING CHECKLIST

## Gate 1 — Audience
- [ ] Specific viewer identified
- [ ] Recognizable problem
- [ ] Desired outcome understood

## Gate 2 — Creative
- [ ] Visual opening
- [ ] Verbal hook
- [ ] Text hook
- [ ] Curiosity/tension
- [ ] Useful payoff
- [ ] Strong pacing

## Gate 3 — Education
- [ ] Viewer learns something
- [ ] Explanation is simple
- [ ] No unnecessary jargon
- [ ] Product is not the only information

## Gate 4 — Evidence
- [ ] Claims have a source
- [ ] Demonstrations are genuine
- [ ] Personal experience is framed as personal
- [ ] No fabricated results

## Gate 5 — Product
- [ ] Product naturally fits the story
- [ ] Correct product
- [ ] Current listing/brief checked
- [ ] Audience fit makes sense

## Gate 6 — Commerce
- [ ] CTA is natural
- [ ] Product path is clear
- [ ] No false urgency
- [ ] Value is understandable

## Gate 7 — Compliance
- [ ] Disclosure handled when required
- [ ] Claims reviewed
- [ ] Before/after reviewed
- [ ] No medical overreach
- [ ] Visuals do not imply unsupported outcomes

## Gate 8 — Learning
- [ ] Test hypothesis documented
- [ ] Primary metric selected
- [ ] Follow-up concept identified

## Final Rule
If the video feels like an advertisement before it feels like useful content, rewrite it.
