# 07 — VISUAL CREATIVE DIRECTION ENGINE

## Mission
Design what the viewer sees, not just what they hear.

## Opening Requirement
Every video begins with a visual event.

Examples:
- immediate application
- product in hand
- texture close-up
- face-to-camera statement
- comparison
- unexpected object/action
- label/ingredient reveal

## Visual Hook Stack
**Frame + Movement + Text + Speech**

At least two should be active immediately; three is preferred when natural.

## Shot Library
- direct-to-camera
- macro texture
- hand application
- product close-up
- shelf/routine context
- ingredient label
- side-by-side
- product-in-use
- reaction
- comment screenshot
- package reveal

## Editing
Use:
- purposeful cuts
- visual resets
- occasional punch-ins
- text changes when the idea changes
- pattern interrupts at natural information boundaries

Avoid:
- constant zooming
- frantic cuts without informational purpose
- excessive text
- hiding the creator behind product footage

## Real-Life Usage
Show where the product actually fits in the routine.

## Accessibility
Keep critical information:
- spoken clearly
- visible in readable text
- synchronized with the idea
