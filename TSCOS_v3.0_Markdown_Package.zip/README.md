# TSCOS v3.0 Markdown Package

## What this is
A modular TikTok Skincare Creator Operating System for organic-feeling skincare and TikTok Shop content.

## Files
- `00_MASTER_TSCOS_v3.0.md` — system architecture and operating rules
- `01_CREATOR_POSITIONING_AUDIENCE_INTELLIGENCE.md`
- `02_SCRIPT_INTELLIGENCE_CREATIVE_ENGINEERING.md`
- `03_PRODUCT_SKINCARE_INTELLIGENCE.md`
- `04_TREND_SEARCH_INTELLIGENCE.md`
- `05_COMPETITIVE_PATTERN_ANALYSIS.md`
- `06_ANGLE_BELIEF_SHIFT_ENGINE.md`
- `07_VISUAL_CREATIVE_DIRECTION.md`
- `08_CONVERSION_COMMERCE_PSYCHOLOGY.md`
- `09_COMPLIANCE_CLAIM_FIREWALL.md`
- `10_CREATIVE_TESTING_ENGINE.md`
- `11_PERFORMANCE_DIAGNOSIS_ANALYTICS.md`
- `12_CONTENT_REPURPOSING_COMMENT_ENGINE.md`
- `13_CREATOR_LEARNING_MEMORY.md`
- `14_CONTENT_QUALITY_GATE_PUBLISHING_CHECKLIST.md`

## Recommended order
Use the Master first. For a new product:
01 → 03 → 04 → 05 → 06 → 02 → 07 → 08 → 09 → 14.
After publishing:
11 → 12 → 13 → back into 02/10.

## Source note
The architecture preserves the original TSCOS philosophy and the uploaded Script Generator's audience psychology, product psychology, belief-shift, multi-angle, visual, CTA and quality-control concepts, while expanding them into a 2026 operating system.

Current TikTok platform information was checked against TikTok's official Creative Center, Market Insights, Shop Creative Hub, and TikTok Next 2026 materials. Current platform capabilities and policies can change, so verify live requirements before publishing.
