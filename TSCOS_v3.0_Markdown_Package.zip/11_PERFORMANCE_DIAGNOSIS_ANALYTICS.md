# 11 — PERFORMANCE DIAGNOSIS & ANALYTICS ENGINE

## Mission
Convert every post into a lesson.

## Diagnostic Funnel
**Impression → 1–3s hold → sustained watch → completion/rewatch → engagement → profile/product interaction → click → order**

## Diagnose by Symptom

### Weak opening
Likely issue:
- unclear promise
- weak visual event
- generic first line
- slow setup

### Strong opening, weak middle
Likely issue:
- promise not fulfilled
- too much filler
- weak information density
- product interruption

### Strong watch, weak clicks
Possible issue:
- product relevance unclear
- CTA weak
- viewer learned but did not understand why the product matters

### Strong clicks, weak orders
Possible issue:
- offer/listing
- price/value perception
- product fit
- shopper uncertainty

Do not automatically blame the script.

## Data Capture
For every meaningful post record:
- date
- product
- concept
- angle
- hook
- length
- views
- watch/retention metrics available
- engagement
- shares/saves
- profile visits
- product clicks
- orders
- GMV/earnings where available
- top comments
- lesson

## Learning Rule
A post is not finished when it is published.
It is finished when its result has been interpreted and stored.
